package edu.okcu.teamproject2;

import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.io.*;
import java.util.Objects;
import java.util.Scanner;

public class StudentTable extends studentLoginController {



    public TextField firstNameBox;
    public TextField lastNameBox;
    public TextField emailBox;
    public TextField ageBox;
    public Label idLabel;
    public TableColumn firstNameColumn;
    public TableColumn lastNameColumn;
    public TableColumn emailColumn;
    public TableColumn ageColumn;
    public Button updateButton;
    public Button clearButton;
    public Button addButton;
    public Button deleteButton;
    public Button clearTextFieldButton;
    static String studentID = "";
    static String firstName = "";
    static String lastName = "";
    static String email = "";
    static String password = "";
    static String salt = "";
    public TableView tableView;

    public void initialize() throws IOException {
        clearTextFieldButton.fire();
        BufferedReader reader = new BufferedReader(new FileReader("StudentData.txt"));
        for (int x = 0; lines>= x; x++) {
            String studentIDChecker = reader.readLine();
            firstName = reader.readLine();
            lastName = reader.readLine();
            email = reader.readLine();
            password =reader.readLine();
            salt = reader.readLine();

            if (Objects.equals(studentIDChecker, studentID)) {
                firstNameColumn.setText(firstName);
                lastNameColumn.setText(lastName);

            }
        }
    }

    public StudentTable() throws FileNotFoundException {
    }

    public void firstNameEntered(ActionEvent actionEvent) {
    }

    public void lastNamedEntered(ActionEvent actionEvent) {
    }

    public void emailEntered(ActionEvent actionEvent) {
    }

    public void ageEntered(ActionEvent actionEvent) {
    }

    public void updateButtonClicked(ActionEvent actionEvent) {
    }

    public void clearButtonClicked(ActionEvent actionEvent) {
    }

    public void deleteButtonClicked(ActionEvent actionEvent) {
    }

    public void onClearTextFieldButton(ActionEvent actionEvent) throws FileNotFoundException {
        idLabel.setText("Student ID: " + studentLoginController.number);
        File file = new File("StudentData.txt");
        Scanner scan = new Scanner(file);
        studentID = idLabel.getText();
        if (Objects.equals(scan.nextLine(), studentID)) {
            firstName = scan.nextLine();
            lastName = scan.nextLine();
            email = scan.nextLine();
            password = scan.nextLine();
            salt = scan.nextLine();
        }




    }

    public void selectRow(MouseEvent mouseEvent) {
    }
}